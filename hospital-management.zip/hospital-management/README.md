# 🏥 MediCore — Hospital Management System

A full-stack web application for hospital management, built with **Node.js + Express + MySQL**.  
This is a modern web port of the original Java/NetBeans project.

---

## ✨ Features

| Module | Features |
|---|---|
| **Patients** | Register, edit, delete, search patients; assign doctors |
| **OPD** | Record outpatient visits with diagnosis |
| **In-Patients** | Admit patients, assign rooms & nurses |
| **Prescriptions** | Order medicines & lab tests per patient |
| **Billing** | Auto-calculate bills (medicines + tests + room charges) |
| **Employees** | Full CRUD for all staff types |
| **Doctors** | Track qualifications; auto-linked on hire |
| **Nurses** | Track assigned patient count |
| **Departments** | Manage 16 departments with auto-head assignment |
| **Rooms** | Room availability tracking with daily cost |
| **Medicines** | 50+ medicines in inventory |
| **Lab Tests** | 10+ diagnostic tests |
| **Salary** | Salary bands per employee type |
| **Triggers** | DB triggers for nurse count, inactive archive, dept head |

---

## 🗂 Project Structure

```
hospital-management/
├── backend/
│   ├── config/
│   │   └── db.js              # MySQL connection pool
│   ├── routes/
│   │   ├── patients.js        # All patient APIs
│   │   ├── employees.js       # All employee APIs
│   │   └── general.js         # Departments, rooms, medicines, tests, stats
│   ├── server.js              # Express entry point
│   ├── .env                   # DB credentials (edit this!)
│   └── package.json
├── frontend/
│   └── index.html             # Complete single-page frontend
└── database/
    └── schema.sql             # Full DB schema + seed data
```

---

## 🚀 Quick Setup

### 1. Prerequisites
- **Node.js** 18+ — [nodejs.org](https://nodejs.org)
- **MySQL** 5.7+ or **MariaDB** 10.3+ — or use WAMP/XAMPP

### 2. Database Setup

Open your MySQL client and run:

```sql
source /path/to/hospital-management/database/schema.sql
```

Or via terminal:
```bash
mysql -u root -p < database/schema.sql
```

### 3. Configure Environment

Edit `backend/.env`:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=hospital_db
DB_PORT=3306
PORT=3000
```

### 4. Install & Run

```bash
cd backend
npm install
npm start
```

Open: **http://localhost:3000**

---

## 🔌 API Reference

### Patients
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/patients` | List all patients |
| GET | `/api/patients/:id` | Full patient detail |
| POST | `/api/patients` | Register patient |
| PUT | `/api/patients/:id` | Update patient |
| DELETE | `/api/patients/:id` | Delete patient |
| POST | `/api/patients/:id/outpatient` | Record OPD visit |
| POST | `/api/patients/:id/inpatient` | Admit to hospital |
| POST | `/api/patients/:id/test` | Order lab test |
| POST | `/api/patients/:id/medicine` | Prescribe medicine |
| POST | `/api/patients/:id/bill` | Generate bill |

### Employees
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/employees` | All employees |
| GET | `/api/employees/:id` | Employee detail |
| POST | `/api/employees` | Add employee |
| PUT | `/api/employees/:id` | Update employee |
| DELETE | `/api/employees/:id` | Remove (archives automatically) |
| GET | `/api/employees/type/doctors` | Doctors only |
| GET | `/api/employees/type/nurses` | Nurses only |

### Hospital Resources
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/departments` | All departments |
| GET | `/api/rooms` | All rooms |
| GET | `/api/rooms/free` | Available rooms only |
| GET | `/api/medicines` | Medicine catalogue |
| GET | `/api/tests` | Lab test catalogue |
| GET | `/api/stats` | Dashboard statistics |
| GET | `/api/inpatients-all` | All current admissions |
| GET | `/api/opd-all` | All OPD records |

---

## 🗃 Database Triggers

| Trigger | When | What |
|---|---|---|
| `transfer_to_passive` | Before DELETE on employee | Archives employee to `employee_inactive` |
| `update_nurse_assigned` | After INSERT on employee | Creates nurse record if type=NURSE |
| `on_insertemployee_update_dept` | After INSERT on employee | Sets dept head if null |
| `transfer_to_prev_department` | After UPDATE on employee (dept change) | Logs department history |
| `decrease_on_discharge` | Before INSERT on bill | Frees room, updates nurse count |

---

## 💻 Technologies

- **Backend**: Node.js, Express.js, mysql2
- **Database**: MySQL / MariaDB
- **Frontend**: Vanilla JS, HTML5, CSS3, Chart.js
- **Design**: DM Serif Display + DM Sans fonts, custom CSS design system

---

## 🔧 Development

```bash
npm install -g nodemon   # if not installed
cd backend
npm run dev              # hot-reload with nodemon
```

---

## 📋 Original Project

Based on the Java/NetBeans Hospital Management project by Vikesh Kumar, Sumit Kumar & Vivek Singh Rana.  
This is a complete web rebuild preserving all database design and business logic.
